import pyodbc
import os
from dotenv import load_dotenv

load_dotenv()

def get_connection(database=None):
    db_name = database if database else os.getenv("DB_NAME")

    conn = pyodbc.connect(
        f"DRIVER={{SQL Server}};"
        f"SERVER={os.getenv('DB_SERVER')};"
        f"DATABASE={db_name};"
        f"Trusted_Connection=yes;"
    )
    return conn