from mcp.server.fastmcp import FastMCP
from db import get_connection

# ✅ Create MCP Server
mcp = FastMCP("DB Assistant")

# 🔍 Tool 1: Get Database Schema (VERY IMPORTANT)
@mcp.tool()
def get_schema(database: str = "cirtification") -> str:
    conn = get_connection(database)
    cursor = conn.cursor()

    schema = ""

    tables = cursor.tables(tableType='TABLE')

    for table in tables:
        table_name = table.table_name
        schema += f"\nTable: {table_name}\nColumns:\n"

        columns = cursor.columns(table=table_name)
        for col in columns:
            schema += f"- {col.column_name} ({col.type_name})\n"

    # 👇 Important relation hint for AI
    schema += "\nRelationship: certifications.employee_id = employees.employee_id\n"

    return schema


# ⚡ Tool 2: Run Query (Dynamic)
@mcp.tool()
def run_query(query: str, database: str = "cirtification") -> list:
    conn = get_connection(database)
    cursor = conn.cursor()

    cursor.execute(query)

    columns = [col[0] for col in cursor.description]
    results = [dict(zip(columns, row)) for row in cursor.fetchall()]

    return results


# 🛡️ Tool 3: Safety Check
@mcp.tool()
def is_safe_query(query: str) -> bool:
    blocked = ["DROP", "DELETE", "TRUNCATE", "ALTER"]

    for word in blocked:
        if word in query.upper():
            return False

    return True


# ▶️ Run MCP Server with HTTP
if __name__ == "__main__":
    import os
    # Use streamable-http transport for HTTP access
    # Set the port via environment variable
    os.environ["UVICORN_PORT"] = "8001"
    mcp.run(transport="streamable-http", mount_path="/mcp")