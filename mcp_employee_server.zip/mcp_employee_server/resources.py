"""MCP resources exposed by the employee server."""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from db import EmployeeService


def register_resources(mcp: FastMCP, service: EmployeeService) -> None:
    """Register MCP resources for employee lookups."""

    @mcp.resource("employee://{employee_id}")
    def employee_resource(employee_id: int) -> str:
        """Return the details for a single employee resource as JSON."""
        employee = service.get_employee_by_id(employee_id)
        return json.dumps(employee, indent=2)

