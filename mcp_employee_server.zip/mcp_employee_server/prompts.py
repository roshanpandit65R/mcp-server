"""MCP prompts exposed by the employee server."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from db import EmployeeService


def register_prompts(mcp: FastMCP, service: EmployeeService) -> None:
    """Register prompts for employee analysis and reporting."""

    @mcp.prompt(
        name="analyze_employee_data",
        description="Summarize employees in a given department.",
    )
    def analyze_employee_data(department: str) -> str:
        """Generate a department-level summary of employees."""
        return service.get_department_summary(department)

    @mcp.prompt(
        name="generate_employee_report",
        description="Generate a formatted report of all employees.",
    )
    def generate_employee_report() -> str:
        """Generate a formatted report that includes all employee records."""
        return service.generate_employee_report()

