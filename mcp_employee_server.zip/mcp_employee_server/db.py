"""Database access layer for employee data."""

from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterator

import pyodbc

from config import Settings


LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class EmployeeRecord:
    """Serializable representation of a row in ``dbo.info_employee``."""

    employee_id: int
    first_name: str
    last_name: str
    email: str
    phone_number: str | None
    hire_date: date
    job_title: str
    salary: Decimal
    department: str
    created_at: datetime

    def to_dict(self) -> dict[str, Any]:
        """Convert the record to a JSON-serializable dictionary."""
        return {
            "employee_id": self.employee_id,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "email": self.email,
            "phone_number": self.phone_number,
            "hire_date": self.hire_date.isoformat(),
            "job_title": self.job_title,
            "salary": str(self.salary),
            "department": self.department,
            "created_at": self.created_at.isoformat(),
        }


@dataclass(frozen=True)
class NewEmployeeInput:
    """Input payload used when creating a new employee record."""

    first_name: str
    last_name: str
    email: str
    phone_number: str | None
    hire_date: date
    job_title: str
    salary: Decimal
    department: str


class EmployeeRepository:
    """Repository for performing CRUD operations on employees."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._connection_string = settings.build_connection_string()

    @contextmanager
    def get_connection(self) -> Iterator[pyodbc.Connection]:
        """Yield a configured pyodbc connection."""
        connection = pyodbc.connect(self._connection_string)
        connection.timeout = self._settings.mssql_command_timeout
        try:
            yield connection
        finally:
            connection.close()

    def fetch_all_employees(self) -> list[EmployeeRecord]:
        """Return all employees ordered by employee identifier."""
        query = """
            SELECT
                employee_id,
                first_name,
                last_name,
                email,
                phone_number,
                hire_date,
                job_title,
                salary,
                department,
                created_at
            FROM dbo.info_employee
            ORDER BY employee_id;
        """
        with self.get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
        return [self._map_row(row) for row in rows]

    def fetch_employee_by_id(self, employee_id: int) -> EmployeeRecord | None:
        """Return a single employee by identifier, if present."""
        query = """
            SELECT
                employee_id,
                first_name,
                last_name,
                email,
                phone_number,
                hire_date,
                job_title,
                salary,
                department,
                created_at
            FROM dbo.info_employee
            WHERE employee_id = ?;
        """
        with self.get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, employee_id)
            row = cursor.fetchone()
        return self._map_row(row) if row else None

    def fetch_employees_by_department(self, department: str) -> list[EmployeeRecord]:
        """Return all employees in a department ordered by last and first name."""
        query = """
            SELECT
                employee_id,
                first_name,
                last_name,
                email,
                phone_number,
                hire_date,
                job_title,
                salary,
                department,
                created_at
            FROM dbo.info_employee
            WHERE department = ?
            ORDER BY last_name, first_name;
        """
        with self.get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, department)
            rows = cursor.fetchall()
        return [self._map_row(row) for row in rows]

    def insert_employee(self, payload: NewEmployeeInput) -> EmployeeRecord:
        """Insert a new employee and return the created record."""
        query = """
            INSERT INTO dbo.info_employee (
                first_name,
                last_name,
                email,
                phone_number,
                hire_date,
                job_title,
                salary,
                department,
                created_at
            )
            OUTPUT INSERTED.employee_id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE());
        """
        parameters = (
            payload.first_name,
            payload.last_name,
            payload.email,
            payload.phone_number,
            payload.hire_date,
            payload.job_title,
            payload.salary,
            payload.department,
        )

        with self.get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, parameters)
            inserted_row = cursor.fetchone()
            if inserted_row is None:
                connection.rollback()
                raise RuntimeError("Employee insert failed: no identifier returned.")

            employee_id = int(inserted_row[0])
            connection.commit()

        created = self.fetch_employee_by_id(employee_id)
        if created is None:
            raise RuntimeError("Employee insert failed: record could not be reloaded.")
        return created

    def delete_employee(self, employee_id: int) -> bool:
        """Delete an employee by identifier and return whether a row was removed."""
        query = "DELETE FROM dbo.info_employee WHERE employee_id = ?;"
        with self.get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, employee_id)
            deleted = cursor.rowcount > 0
            connection.commit()
        return deleted

    @staticmethod
    def _map_row(row: pyodbc.Row) -> EmployeeRecord:
        """Convert a pyodbc row to an ``EmployeeRecord``."""
        return EmployeeRecord(
            employee_id=int(row.employee_id),
            first_name=str(row.first_name),
            last_name=str(row.last_name),
            email=str(row.email),
            phone_number=str(row.phone_number) if row.phone_number is not None else None,
            hire_date=row.hire_date,
            job_title=str(row.job_title),
            salary=row.salary if isinstance(row.salary, Decimal) else Decimal(row.salary),
            department=str(row.department),
            created_at=row.created_at,
        )


class EmployeeService:
    """Application service that adds validation and business-facing responses."""

    def __init__(self, repository: EmployeeRepository) -> None:
        self._repository = repository

    def get_all_employees(self) -> list[dict[str, Any]]:
        """Return all employees as dictionaries."""
        employees = self._repository.fetch_all_employees()
        return [employee.to_dict() for employee in employees]

    def get_employee_by_id(self, employee_id: int) -> dict[str, Any]:
        """Return a single employee or raise if it does not exist."""
        employee = self._repository.fetch_employee_by_id(employee_id)
        if employee is None:
            raise ValueError(f"Employee with ID {employee_id} was not found.")
        return employee.to_dict()

    def add_employee(
        self,
        *,
        first_name: str,
        last_name: str,
        email: str,
        phone_number: str | None,
        hire_date: str,
        job_title: str,
        salary: str | float,
        department: str,
    ) -> dict[str, Any]:
        """Validate employee data, insert it, and return the created record."""
        cleaned_first_name = first_name.strip()
        cleaned_last_name = last_name.strip()
        cleaned_email = email.strip()
        cleaned_job_title = job_title.strip()
        cleaned_department = department.strip()
        cleaned_phone_number = phone_number.strip() if phone_number else None

        if not cleaned_first_name:
            raise ValueError("first_name is required.")
        if not cleaned_last_name:
            raise ValueError("last_name is required.")
        if not cleaned_email:
            raise ValueError("email is required.")
        if not cleaned_job_title:
            raise ValueError("job_title is required.")
        if not cleaned_department:
            raise ValueError("department is required.")

        try:
            parsed_hire_date = date.fromisoformat(hire_date)
        except ValueError as exc:
            raise ValueError("hire_date must be in YYYY-MM-DD format.") from exc

        try:
            parsed_salary = Decimal(str(salary))
        except Exception as exc:  # noqa: BLE001
            raise ValueError("salary must be a valid decimal value.") from exc

        if parsed_salary < 0:
            raise ValueError("salary must be zero or greater.")

        payload = NewEmployeeInput(
            first_name=cleaned_first_name,
            last_name=cleaned_last_name,
            email=cleaned_email,
            phone_number=cleaned_phone_number,
            hire_date=parsed_hire_date,
            job_title=cleaned_job_title,
            salary=parsed_salary,
            department=cleaned_department,
        )
        created = self._repository.insert_employee(payload)
        LOGGER.info("Created employee with ID %s", created.employee_id)
        return created.to_dict()

    def delete_employee(self, employee_id: int) -> dict[str, Any]:
        """Delete an employee and return a structured result."""
        deleted = self._repository.delete_employee(employee_id)
        if not deleted:
            raise ValueError(f"Employee with ID {employee_id} was not found.")
        LOGGER.info("Deleted employee with ID %s", employee_id)
        return {"deleted": True, "employee_id": employee_id}

    def get_department_summary(self, department: str) -> str:
        """Return a natural-language summary for a department."""
        cleaned_department = department.strip()
        if not cleaned_department:
            raise ValueError("department is required.")

        employees = self._repository.fetch_employees_by_department(cleaned_department)
        if not employees:
            return f"No employees were found in the {cleaned_department} department."

        total_salary = sum((employee.salary for employee in employees), Decimal("0"))
        average_salary = total_salary / Decimal(len(employees))
        titles = sorted({employee.job_title for employee in employees})
        names = ", ".join(
            f"{employee.first_name} {employee.last_name}" for employee in employees
        )

        return (
            f"Department: {cleaned_department}\n"
            f"Employee count: {len(employees)}\n"
            f"Average salary: {average_salary.quantize(Decimal('0.01'))}\n"
            f"Roles represented: {', '.join(titles)}\n"
            f"Employees: {names}"
        )

    def generate_employee_report(self) -> str:
        """Return a formatted report covering all employees."""
        employees = self._repository.fetch_all_employees()
        if not employees:
            return "Employee report: no employee records are currently available."

        lines: list[str] = ["Employee Report", "================"]
        for employee in employees:
            lines.extend(
                [
                    f"ID: {employee.employee_id}",
                    f"Name: {employee.first_name} {employee.last_name}",
                    f"Email: {employee.email}",
                    f"Phone: {employee.phone_number or 'N/A'}",
                    f"Hire Date: {employee.hire_date.isoformat()}",
                    f"Job Title: {employee.job_title}",
                    f"Salary: {employee.salary}",
                    f"Department: {employee.department}",
                    f"Created At: {employee.created_at.isoformat()}",
                    "----------------",
                ]
            )
        return "\n".join(lines[:-1])

