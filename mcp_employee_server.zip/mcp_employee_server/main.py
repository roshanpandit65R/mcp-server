"""Entrypoint for the employee MCP server."""

from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from config import Settings
from db import EmployeeRepository, EmployeeService
from prompts import register_prompts
from resources import register_resources
from tools import register_tools


def configure_logging(level: str) -> None:
    """Configure application logging."""
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def create_server() -> FastMCP:
    """Create and configure the FastMCP server instance."""
    settings = Settings.from_env()
    configure_logging(settings.log_level)

    repository = EmployeeRepository(settings)
    service = EmployeeService(repository)

    mcp = FastMCP(
        name="employee-mcp-server",
        instructions=(
            "This MCP server provides employee data from the dbo.info_employee "
            "table in Microsoft SQL Server."
        ),
        host=settings.host,
        port=settings.port,
    )

    register_tools(mcp, service)
    register_resources(mcp, service)
    register_prompts(mcp, service)
    return mcp


mcp = create_server()

# Friendly default endpoints for browser checks.
@mcp.custom_route("/", methods=["GET"], include_in_schema=False)
async def root(_: Request) -> JSONResponse:
    return JSONResponse(
        {
            "name": "employee-mcp-server",
            "status": "ok",
            "mcp_endpoint": "/mcp",
        }
    )


@mcp.custom_route("/favicon.ico", methods=["GET"], include_in_schema=False)
async def favicon(_: Request) -> Response:
    return Response(status_code=204)


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
