"""MCP tools exposed by the employee server."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from db import EmployeeService


def register_tools(mcp: FastMCP, service: EmployeeService) -> None:
    """Register employee CRUD tools with the MCP server."""

    @mcp.tool(
        name="get_all_employees",
        description="Return all rows from dbo.info_employee.",
    )
    def get_all_employees() -> list[dict[str, object]]:
        """Fetch all employee records from the SQL Server database."""
        return service.get_all_employees()

    @mcp.tool(
        name="get_employee_by_id",
        description="Return one employee from dbo.info_employee by employee_id.",
    )
    def get_employee_by_id(employee_id: int) -> dict[str, object]:
        """Fetch a single employee record by its integer employee ID."""
        return service.get_employee_by_id(employee_id)

    @mcp.tool(
        name="add_employee",
        description="Insert a new row into dbo.info_employee and return the created employee.",
    )
    def add_employee(
        first_name: str,
        last_name: str,
        email: str,
        phone_number: str | None,
        hire_date: str,
        job_title: str,
        salary: str,
        department: str,
    ) -> dict[str, object]:
        """Create a new employee record in the database using validated input fields."""
        return service.add_employee(
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone_number=phone_number,
            hire_date=hire_date,
            job_title=job_title,
            salary=salary,
            department=department,
        )

    @mcp.tool(
        name="delete_employee",
        description="Delete a row from dbo.info_employee by employee_id.",
    )
    def delete_employee(employee_id: int) -> dict[str, object]:
        """Delete an employee record by ID and return whether the deletion succeeded."""
        return service.delete_employee(employee_id)

