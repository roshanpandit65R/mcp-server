"""Application configuration for the employee MCP server."""

from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


load_dotenv()


@dataclass(frozen=True)
class Settings:
    """Runtime settings loaded from environment variables."""

    mssql_connection_string: str | None
    mssql_driver: str
    mssql_server: str
    mssql_database: str
    mssql_username: str
    mssql_password: str
    mssql_encrypt: str
    mssql_trust_server_certificate: str
    mssql_connection_timeout: int
    mssql_command_timeout: int
    host: str
    port: int
    log_level: str

    @classmethod
    def from_env(cls) -> "Settings":
        """Create application settings from environment variables."""
        return cls(
            mssql_connection_string=_get_optional("MSSQL_CONNECTION_STRING"),
            mssql_driver=os.getenv("MSSQL_DRIVER", "ODBC Driver 18 for SQL Server"),
            mssql_server=os.getenv("MSSQL_SERVER", ""),
            mssql_database=os.getenv("MSSQL_DATABASE", ""),
            mssql_username=os.getenv("MSSQL_USERNAME", ""),
            mssql_password=os.getenv("MSSQL_PASSWORD", ""),
            mssql_encrypt=os.getenv("MSSQL_ENCRYPT", "yes"),
            mssql_trust_server_certificate=os.getenv(
                "MSSQL_TRUST_SERVER_CERTIFICATE", "yes"
            ),
            mssql_connection_timeout=_get_int("MSSQL_CONNECTION_TIMEOUT", 30),
            mssql_command_timeout=_get_int("MSSQL_COMMAND_TIMEOUT", 30),
            host=os.getenv("MCP_HOST", "127.0.0.1"),
            port=_get_int("MCP_PORT", 8000),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        )

    def build_connection_string(self) -> str:
        """Return a pyodbc connection string."""
        if self.mssql_connection_string:
            return self.mssql_connection_string

        required_values: dict[str, str] = {
            "MSSQL_SERVER": self.mssql_server,
            "MSSQL_DATABASE": self.mssql_database,
            "MSSQL_USERNAME": self.mssql_username,
            "MSSQL_PASSWORD": self.mssql_password,
        }
        missing: list[str] = [name for name, value in required_values.items() if not value]
        if missing:
            joined = ", ".join(missing)
            raise ValueError(
                f"Missing required database configuration: {joined}. "
                "Set MSSQL_CONNECTION_STRING or all individual MSSQL_* values."
            )

        return (
            f"DRIVER={{{self.mssql_driver}}};"
            f"SERVER={self.mssql_server};"
            f"DATABASE={self.mssql_database};"
            f"UID={self.mssql_username};"
            f"PWD={self.mssql_password};"
            f"Encrypt={self.mssql_encrypt};"
            f"TrustServerCertificate={self.mssql_trust_server_certificate};"
            f"Connection Timeout={self.mssql_connection_timeout};"
        )


def _get_optional(name: str) -> str | None:
    """Return an environment variable value or ``None`` if blank."""
    value = os.getenv(name)
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


def _get_int(name: str, default: int) -> int:
    """Return an integer environment variable value."""
    raw_value = os.getenv(name)
    if raw_value is None or raw_value.strip() == "":
        return default

    try:
        return int(raw_value)
    except ValueError as exc:
        raise ValueError(f"Environment variable {name} must be an integer.") from exc

